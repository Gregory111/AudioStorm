-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Мар 02 2017 г., 15:44
-- Версия сервера: 10.1.13-MariaDB
-- Версия PHP: 7.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `audiostorm`
--

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `article` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `title`, `article`, `image`, `url`, `updated_at`, `created_at`) VALUES
(1, 'אוזניות', '<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC.</p><p><br></p>', '2017.02.28.11.19.04-2017.02.18.10.34.33-headphones.jpg', 'אוזניות', '2017-02-28 11:19:04', '2017-01-10 14:54:00'),
(2, 'רמקולים', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don''t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn''t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary.', '2017.02.28.11.19.11-loudspeakers.jpg', 'רמקולים', '2017-02-28 11:19:11', '2017-01-10 14:57:00'),
(3, 'רמקולים ניידים', ' Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '2017.02.28.11.19.17-portable-speaker.jpg', 'רמקולים-ניידים', '2017-02-28 11:19:17', '2017-01-10 14:58:00'),
(6, 'mp3', 'mp3 musik', '2017.02.28.11.19.45-noimage.jpg', 'mp3', '2017-02-28 11:19:45', '2017-02-04 08:39:46'),
(9, 'czxczxc', 'cscCC', 'noimage.jpg', 'czxczxc', '2017-03-02 09:37:29', '2017-03-02 09:37:29');

-- --------------------------------------------------------

--
-- Структура таблицы `contents`
--

CREATE TABLE `contents` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `article` text NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `contents`
--

INSERT INTO `contents` (`id`, `menu_id`, `title`, `article`, `updated_at`, `created_at`) VALUES
(1, 4, 'About our company', 'דף אודות של האתר', '2017-01-25 00:00:00', '2017-01-25 00:00:00'),
(2, 4, 'About', '<p>company in Israel</p><p>,,,,,</p>', '2017-03-02 14:35:03', '2017-01-25 00:00:00'),
(3, 3, 'צור קשר', '<!-- INFO -->\r\n						<div class="col-md-3 col-sm-3">\r\n\r\n							<h2>Visit Us</h2>\r\n\r\n							<p>\r\n								Lid est laborum dolo rumes fugats untras. Etharums ser quidem rerum facilis dolores nemis omnis fugats vitaes nemo minima rerums unsers sadips amets.\r\n							</p>\r\n\r\n							<hr>\r\n\r\n							<p>\r\n								<span class="block"><strong><i class="fa fa-map-marker"></i> Address:</strong> Street Name, City Name, Country</span>\r\n								<span class="block"><strong><i class="fa fa-phone"></i> Phone:</strong> <a href="tel:1800-555-1234">1800-555-1234</a></span>\r\n								<span class="block"><strong><i class="fa fa-envelope"></i> Email:</strong> <a href="mailto:mail@yourdomain.com">mail@yourdomain.com</a></span>\r\n							</p>\r\n\r\n							<hr>\r\n\r\n							<h4 class="font300">Business Hours</h4>\r\n							<p>\r\n								<span class="block"><strong>Monday - Friday:</strong> 10am to 6pm</span>\r\n								<span class="block"><strong>Saturday:</strong> 10am to 2pm</span>\r\n								<span class="block"><strong>Sunday:</strong> Closed</span>\r\n							</p>\r\n\r\n						</div>\r\n						<!-- /INFO -->', '2017-03-02 13:55:46', '2017-01-25 00:00:00'),
(5, 12, 'popeye', '<p><span style="font-size: 24px;">dfsd fsdgs sg</span> rw gwertg <span style="color: rgb(255, 0, 0);">wert wrt gw4</span>r w4r w</p><p>_____________________________________________________||||||||||||||||||||||||||||||</p>', '2017-02-03 11:35:52', '2017-02-02 20:05:06');

-- --------------------------------------------------------

--
-- Структура таблицы `facebook_users`
--

CREATE TABLE `facebook_users` (
  `open_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `link` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `menus`
--

INSERT INTO `menus` (`id`, `link`, `title`, `url`, `updated_at`, `created_at`) VALUES
(3, 'צור קשר', 'Contact us', 'contact', '2017-01-23 00:00:00', '2017-01-23 00:00:00'),
(4, 'אודות', 'About us', 'about-us', '2017-01-25 00:00:00', '2017-01-25 00:00:00'),
(5, 'שרותים', 'Servises', 'servises', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `data` text NOT NULL,
  `total` decimal(8,2) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `data`, `total`, `updated_at`, `created_at`) VALUES
(1, 5, 'a:2:{i:10;a:6:{s:2:"id";s:2:"10";s:4:"name";s:19:"Z130 2.0 Logitech\r\n";s:5:"price";d:149.90000000000001;s:8:"quantity";i:4;s:10:"attributes";a:0:{}s:10:"conditions";a:0:{}}i:7;a:6:{s:2:"id";s:1:"7";s:4:"name";s:29:"Bluetooth Creative Woof 3\r\n\r\n";s:5:"price";d:235.5;s:8:"quantity";i:6;s:10:"attributes";a:0:{}s:10:"conditions";a:0:{}}}', '2012.60', '2017-01-23 18:58:23', '2017-01-23 18:58:23'),
(2, 8, 'a:3:{i:1;a:6:{s:2:"id";s:1:"1";s:4:"name";s:47:"Logitech G633 Artemis Spectrum Gaming RGB 7.1\r\n";s:5:"price";d:1350.5999999999999;s:8:"quantity";i:1;s:10:"attributes";a:0:{}s:10:"conditions";a:0:{}}i:10;a:6:{s:2:"id";s:2:"10";s:4:"name";s:19:"Z130 2.0 Logitech\r\n";s:5:"price";d:149.90000000000001;s:8:"quantity";i:2;s:10:"attributes";a:0:{}s:10:"conditions";a:0:{}}i:3;a:6:{s:2:"id";s:1:"3";s:4:"name";s:30:"SteelSeries Siberia 800 \r\n\r\n\r\n";s:5:"price";d:750;s:8:"quantity";i:2;s:10:"attributes";a:0:{}s:10:"conditions";a:0:{}}}', '3150.40', '2017-01-23 19:00:49', '2017-01-23 19:00:49'),
(3, 5, 'a:2:{i:1;a:6:{s:2:"id";s:1:"1";s:4:"name";s:47:"Logitech G633 Artemis Spectrum Gaming RGB 7.1\r\n";s:5:"price";d:1350.5999999999999;s:8:"quantity";i:1;s:10:"attributes";a:0:{}s:10:"conditions";a:0:{}}i:2;a:6:{s:2:"id";s:1:"2";s:4:"name";s:40:"Bluetooth Plantronics Backbeat Pro 2  \r\n";s:5:"price";d:900;s:8:"quantity";i:1;s:10:"attributes";a:0:{}s:10:"conditions";a:0:{}}}', '2250.60', '2017-02-11 11:47:01', '2017-02-11 11:47:01'),
(4, 5, 'a:1:{i:10;a:6:{s:2:"id";s:2:"10";s:4:"name";s:19:"Z130 2.0 Logitech\r\n";s:5:"price";d:149.90000000000001;s:8:"quantity";i:1;s:10:"attributes";a:0:{}s:10:"conditions";a:0:{}}}', '149.90', '2017-02-11 11:55:50', '2017-02-11 11:55:50'),
(5, 5, 'a:1:{i:10;a:6:{s:2:"id";s:2:"10";s:4:"name";s:19:"Z130 2.0 Logitech\r\n";s:5:"price";d:149.90000000000001;s:8:"quantity";i:1;s:10:"attributes";a:0:{}s:10:"conditions";a:0:{}}}', '149.90', '2017-02-11 12:04:01', '2017-02-11 12:04:01'),
(6, 5, 'a:1:{i:6;a:6:{s:2:"id";s:1:"6";s:4:"name";s:53:"Philips Bluetooth Wireless Portable Speaker BT2200B\r\n";s:5:"price";d:245;s:8:"quantity";i:1;s:10:"attributes";a:0:{}s:10:"conditions";a:0:{}}}', '245.00', '2017-02-11 12:07:01', '2017-02-11 12:07:01'),
(7, 5, 'a:1:{i:10;a:6:{s:2:"id";s:2:"10";s:4:"name";s:19:"Z130 2.0 Logitech\r\n";s:5:"price";d:149.90000000000001;s:8:"quantity";i:1;s:10:"attributes";a:0:{}s:10:"conditions";a:0:{}}}', '149.90', '2017-02-11 12:09:09', '2017-02-11 12:09:09'),
(8, 5, 'a:1:{i:9;a:6:{s:2:"id";s:1:"9";s:4:"name";s:37:"Bluetooth Wireless T15 Creative 2.0\r\n";s:5:"price";d:420;s:8:"quantity";i:1;s:10:"attributes";a:0:{}s:10:"conditions";a:0:{}}}', '420.00', '2017-02-11 12:10:28', '2017-02-11 12:10:28'),
(9, 5, 'a:1:{i:9;a:6:{s:2:"id";s:1:"9";s:4:"name";s:37:"Bluetooth Wireless T15 Creative 2.0\r\n";s:5:"price";d:420;s:8:"quantity";i:1;s:10:"attributes";a:0:{}s:10:"conditions";a:0:{}}}', '420.00', '2017-02-11 12:11:32', '2017-02-11 12:11:32'),
(10, 5, 'a:1:{i:7;a:6:{s:2:"id";s:1:"7";s:4:"name";s:25:"Bluetooth Creative Woof 3";s:5:"price";d:255.5;s:8:"quantity";i:1;s:10:"attributes";a:0:{}s:10:"conditions";a:0:{}}}', '255.50', '2017-02-11 12:12:20', '2017-02-11 12:12:20');

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `categorie_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `article` text NOT NULL,
  `url` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `categorie_id`, `title`, `article`, `url`, `image`, `price`, `updated_at`, `created_at`) VALUES
(1, 1, 'Logitech G633 Artemis Spectrum Gaming RGB 7.1', 'מותג Logitech\r\nדגם G633 Artemis Spectrum 981-000586\r\nסוג קשת גיימינג + מיקרופון\r\nחיבור PL 3.5mm\r\n\r\nUSB\r\nמאפיינים טכניים דרייבר: 40 מ"מ\r\nתדרי תגובה: 20Hz~20KHz\r\nעכבה: 39Ω\r\nכ.קול המדמה סראונד 7.1 דולבי\r\nהתאמה אישית של התאורה\r\nפרופילי שמע מותאמים אישית\r\nמיקרופון נשלף הכולל ביטול רעשים אקטיבי\r\nתאימות PS4\r\n\r\nXbox One\r\nמיקרופון 100Hz~20KHz\r\nצבע שחור\r\nאחריות שנתיים', 'logitech-G633', '2017.02.28.10.54.14-2017.02.28.09.50.58-logitech-G633-1 - Copy.jpg', '1350.60', '2017-02-28 10:54:14', '2017-01-11 11:36:00'),
(2, 1, 'Bluetooth Plantronics Backbeat Pro 2  ', 'מותג Plantronics\r\nדגם Backbeat Pro 2\r\nסוג קשת אלחוטיות + מיקרופון\r\nחיבור Bluetooth\r\nPL3.5mm\r\nמאפיינים טכניים ביטול רעשים אקטיבי (ANC)\r\nדרייבר 40 מ"מ\r\nעד 3 שעות טעינה\r\nעד 24 שעות האזנה\r\nטווח קליטה: עד 100 מטר\r\nמשקל: כ 289 גרם\r\nBluetooth® 4.0 + EDR, HSP 1.2, HFP 1.6 \r\nתאימות \r\nTablet\r\nMobile Phone\r\nPC\r\nMac\r\nמיקרופון כלול\r\nצבע שחור וחום\r\nאחריות שנתיים ע"י היבואן הרשמי', 'plantronics-Backbeat-Pro-2', '2017.02.28.11.08.49-plantronics-Backbeat-Pro-2-1.jpg', '900.00', '2017-02-28 11:08:49', '2017-01-11 11:40:00'),
(3, 1, 'SteelSeries Siberia 800 ', 'אחריות\r\nשנתיים\r\nדגם\r\nSiberia 800\r\nמק''''ט\r\n61302\r\nסקירה\r\nאוזניות הגיימרים המקצועיות והאלחוטיות מבית SteelSeries מגיעות בגודל מלא עם טכנולוגיית DOLBY ומיועדות לטורנירים ארוכים ולשעות של שימוש.\r\nלאוזניות רמקולים בגודל 40 מ''''מ, טווח אלחוטי של עד 10 מטר, סוללות חזקות המאפשרות שימוש רציף של עד 20 שעות, מיקרופון המסנן רעשי רקע נשלף, כריות אוזן מרופדות אטומות לרעשי הסביבה, משדר אלחוטי המאפשר איזון קול בין שיחות הצ''אט עם חברים לאקשן בשדה הקרב, תצורת 7.1 ערוצים וירטואלים בטכנולוגיית DOLBY עם בקר שליטה בעוצמת הווליום על האוזניות עצמן ועיצוב אשר מושך את העין.\r\nבנוסף, האוזניות מתאימות למגוון רחב של מערכות הפעלה ולקונסולות המשחק המוכרות כגון פלייסטיישן ואקסבוקס (בעזרת מתאם).\r\nאוזניות\r\nרמקולים: 40 מ''''מ מגנטי ניאודימיום\r\nתגובת תדר: 20-20000KHz\r\nרגישות: 100dB SPL\r\nטווח אלחוטי: 10 מטר\r\nמשקל: 318 גרם כולל סוללה\r\nמיקרופון\r\nתגובת תדר 100-10000Hz\r\nעכבה: 2.2K Ohm\r\nרגישות: 44dB-\r\nMic Pattern: Unidirectional\r\nנורת LED אדומה לחיווי בזמן ההשתקה\r\nבתוך האריזה\r\nאוזניות\r\nמשדר\r\n2 סוללות ליתיום נטענות\r\nכבל חשמל\r\nכבל USB\r\nכבל אופטי\r\nכבל אנלוגי\r\nמטען\r\nתאימות: Xbox, Mobile, Playstation, Mac, PC (בעזרת מתאם)', 'steelSeries-Siberia-800', '2017.02.28.11.09.20-steelSeries-Siberia-800-1.jpg', '750.00', '2017-02-28 11:09:20', '2017-01-11 11:42:00'),
(4, 1, 'Sennheiser MOMENTUM In Ear ', 'מותג Sennheiser\r\nדגם MOMENTUM 506231\r\nסוג תוך אוזן\r\nIn - Ear\r\nחיבור PL 3.5mm\r\nמאפיינים טכניים טווח תדרים: 15Hz - 22000Hz\r\nהתנגדות: 18Ω\r\nאורך כבל: 1.3 מטר\r\n\r\nתומך Apple בלבד\r\nמיקרופון 100Hz - 10,000Hz\r\nצבע שחור ואדום\r\nאחריות שנתיים ע"י היבואן הרשמי', 'sennheiser-MOMENTUM-In-Ear', '2017.02.28.11.09.39-sennheiser-MOMENTUM-In-Ear-1.jpg', '475.00', '2017-02-28 11:09:39', '2017-01-11 11:45:00'),
(5, 1, 'Samsung Gear IconX Cord-free Fitness SM-R150', 'אחריות\r\nשנה אחת\r\nדגם\r\nSM-R150\r\nסקירה\r\nללא כבלים\r\nאין פשוט מזה. חבר את אוזניות IconX לכל אוזן ואתה יכול ללכת. ללא צורך בחוטים.\r\nעיצוב עם התאמה מושלמת\r\nהתאמה עם נעילה בטוחה במקום\r\nה-Gear IconX יושבים בטוחים באוזניך בצורה הנוחה ביותר שיש. וכן, אתה יכול לרוץ, לקפוץ ולהמשיך בחיים. הם עוצבו להישאר במקום.\r\nמעקב כושר\r\nללא הצורך בטלפון, ה-Gear IconX עושה את העבודה בשבילך. בין אם אתה הולך או רץ, המערכת חכמה מספיק כדי לעקוב אחרי הפעילות שלך ולספק לך עדכונים על הנתונים החיוניים ממהירות, מרחק ומשך זמן ועד לדופק וקלוריות שנשרפו דרך מדריך קולי ייעודי.\r\n*כלי ניטור הדופק: מיועד למטרות כושר ואינו מיועד לאבחון כל מחלה או מצב בריאותי או למתן, למנוע, לטפל או לרפות אף מחלה.\r\nעקוב אחרי הסטטיסטיקות שלך\r\nרוץ עם המדריך הקולי בתוך האוזן של Gear IconX כדי להגיע לאזור העוצמה הגבוהה שלך. המדריך הוקלט על ידי אנשים אמיתיים ב-15 שפות שונות, מה שהופך את המוטיבציה לאישית יותר. על ידי סנכרון עם הטלפון החכם שלך לאחר האימונים תוכל לבדוק את הסטטיסטיקות שלך ולנטר את ההתקדמות שלך באפליקציית S Health.\r\nהישאר מודע\r\nהפעל את מצב קולות הסביבה כדי לשמוע את הסביבה שלך. כך תוכל לצעוד בכיף עם השירים המועדפים עליך בזמן שאתה עדיין נוכח ומודע לעולם.\r\nהבא את השירים שלך\r\nGear IconX הוא לא רק כלי מעקב כושר פונקציונלי במיוחד, קרוב לוודאי שהוא גם נגן המוזיקה הקטן ביותר בעולם, מה שאומר שאוזניות אלה הן כל מה שאתה צריך כדי לצאת לריצה. עם זיכרון פנימי בגודל 4 GB שמספיק ל-1,000 שירים, ייגמר לך האוויר לפני שייגמרו לך השירים לתדלוק האימון שלך. תוכל גם לשמור על הקצב דרך הזרמת Bluetooth, כך שלעולם לא תישאר תקוע בלי שירים שימריצו את האימון שלך.\r\nקטן ועוצמתי\r\nהחיים חזקים עם Gear IconX עם כיסוי שמשמש גם כמטען, תוכל להטעין את ה-Gear IconX שלך בזמן שהם לא נמצאים בשימוש, מה שמאפשר לך להסתער על האימונים העוצמתיים שלך עם פסקול מצוין מבלי להחמיץ אף פעימה.\r\nשליטה במגע\r\nהקש והחזק כדי לשמוע פקודות קוליות שידריכו אותך לגבי הפונקציות של Gear IconX מניגון מוזיקה וקבלת או דחיית שיחות ועד להפעלת מצב קולות הסביבה. כאשר אתה שומע את הפונקציה שאתה צריך, הסר את האצבע כדי להפעיל אותה.\r\nתאימות\r\nGear IconX עוצבו כדי לעבוד איתך, עם צרכי הכושר שלך ועם הטלפון החכם שלך בצורה אופטימלית. הם מוכנים ברגע שאתה מוכן. חבר ורוץ.\r\n*מתאים למכשירים עם Android 4.4 KitKat ומעלה עם RAM של לפחות 1.5 GB. המשתמשים בטלפון מסוג Galaxy יכולים להעביר את קבצי המוזיקה שלהם ל-Gear IconX מטלפון ה-Galaxy או מהמחשב בעזרת מחברי או כבלי USB (לא חל על חלק מטלפוני ה-Galaxy). המשתמשים בטלפונים עם מערכת ההפעלה Android שאינם מסוג Galaxy יכולים להעביר קבצי מוזיקה ל-Gear IconX ממחשב אישי בעזרת כבל USB.\r\nזכרון\r\n3.5GB\r\nקישוריות\r\nגרסת USB\r\nUSB 2.0\r\nגרסת בלוטות''\r\nBluetooth v4.1\r\nפרופיל בלוטות''\r\nA2DP, AVRCP, HFP\r\nסנכרון למחשב\r\nמנהל המחשב האישי של Gear IconX\r\nחיישנים\r\nחיישן דופק, מד תאוצה\r\nסוללה\r\nאוזניות: 47mAh\r\nמארז: 315mAh\r\nשמע\r\nתגובת תדר: 20-20kHz\r\nרגישות: 89.5dB ± 3 dB / 1mW\r\nעכבה: 16ohm\r\nפורמטים נתמכים\r\nפורמט השמעת אודיו\r\nMP3, M4A, AAC, WAV, WMA (WMA v9)\r\nמימדים\r\nאוזניות: 18.9x26.4x26.0 מ"מ\r\nמארז: 35.3x30.3x92 מ"מ', 'samsung-Gear-IconX-Cord-free-Fitness-SM-R150', '2017.02.28.11.09.47-samsung-Gear-IconX-Cord-free-Fitness-SM-R150-1.jpg', '920.00', '2017-02-28 11:09:47', '2017-01-11 11:47:00'),
(6, 3, 'Philips Bluetooth Wireless Portable Speaker BT2200B', 'מותג Philips\r\nדגם  BT2200B\r\nהספק רמקול 2.8W\r\nממשק Bluetooth 4.0\r\nAudio-in\r\nשונות  טווח קליטה: עד 10 מטר\r\nסוללה נטענת\r\nמיקרופון מובנה\r\nAnti-clipping\r\nתקן IPX6 לעמידות במים\r\nמידות: כ- 107x 58 x 69mm\r\nמשקל: כ-0.2 ק"ג\r\nאחריות 3 שנים', 'philips-Bluetooth-Wireless-Portable-Speaker-BT2200B', '2017.02.28.11.10.37-philips-Bluetooth-Wireless-Portable-Speaker-BT2200B-1.jpg', '245.00', '2017-02-28 11:10:37', '2017-01-11 12:15:00'),
(7, 3, 'Bluetooth Creative Woof 3', 'אחריות\r\nשנה אחת\r\nדגם\r\nWoof 3\r\nסקירה\r\nהרמקול הנייד האיכותי מבית Creative מגיע בגודל קטן אשר מתאים בדיוק לכף היד שלכם ועדיין עומד בסטנדרטים לביצועי השמע המדהימים שהוא מספק כולל בס עוצמתי ורמקול פנימי בגודל 45 מ''''מ, להזרמת המוסיקה באופן אלחוטי ובעיצוב אקוסטי ואלגנטי עם מיקרופון מובנה המאפשר גם לבצע שיחות ברמקול ישירות מהנייד.\r\nמגיע בנוסף עם ממשקים נוספים כגון חיבור 3.5 מ''''מ, כרטיס זיכרון microSD או חיבור USB ובעל חיי סוללה של עד 6 שעות.\r\nמיקרופון\r\nמיקרופון מובנה\r\nקישוריות\r\nבלוטות'' גירסא 2.1 + EDR\r\nחיבור 3.5 מ''''מ\r\nמיקרו USB\r\nקורא כרטיסים microSD\r\nפרופילים נתמכים\r\nA2DP, AVRCP, HFP\r\nמימדים\r\nרוחב: 65 מ''''מ\r\nעומק: 68 מ''''מ\r\nגובה: 75 מ''''מ\r\nמשקל\r\n237 גרם\r\nתכולת הערכה\r\nרמקול נייד\r\nכבל USB\r\nמדריך משתמש', 'bluetooth-Creative-Woof-3', '2017.02.28.11.10.53-bluetooth-Creative-Woof-3-1 - Copy.jpg', '255.50', '2017-02-28 11:10:53', '2017-01-11 12:16:00'),
(8, 3, 'Bluetooth Creative iRoar Go Splash-proof', 'אחריות\r\nשנה אחת\r\nדגם\r\niRoar Go\r\nסקירה\r\nהרמקול הנייד והאיכותי מבית Creative מאפשר לכם ליהנות מאיכות שמע מעולה מכל כיוון ב-360 מעלות ולהזרים את המוסיקה באופן אלחוטי ובעיצוב אקוסטי ואלגנטי עם מיקרופונים מובנים המאפשרים לקלוט סאונד מכל מקום בסביבה ומעבד עוצמתי המורכב בכרטיסי הקול הטובים ביותר היכול לערבל ולשנות את הקול שלכם לדמויות מצחיקות כך שגם תוכלו לעבוד על החברים שלכם במתיחה.\r\nבנוסף, הרמקול בעל 5 רמקולים לאקוסטיקה טובה, כפתורי מגע וניתן לשלוט בו ע''''י אפליקציה ייעודית ולנהל אותו עם הסמארטפון ממש כמו שלט אלחוטי.\r\nמגיע בנוסף עם ממשקים נוספים כגון חיבור 3.5 מ''''מ, כרטיס זיכרון microSD, חיישן קרבה NFC או חיבור USB ובעל חיי סוללה ארוכים של עד 20 שעות ומאפשר חיבור של 2 מכשירים בו זמנית.\r\nמיקרופון\r\nמיקרופונים מובנים\r\nקישוריות\r\nבלוטות''\r\nחיבור 3.5 מ''''מ\r\nמיקרו USB\r\nקורא כרטיסים microSD\r\nחיישן קרבה NFC\r\nסוללה\r\nסוג סוללה: ליתיום 9000mAh\r\nזמן פעולה: עד 20 שעות\r\nזמן טעינה: כ-3 שעות\r\nתכולת הערכה\r\nרמקול נייד\r\nכבל USB\r\nספק כח\r\nמדריך משתמש\r\nנרתיק נשיאה\r\nדרישות מערכת\r\nמכשירי אנדרואיד עם מערכת הפעלה אנדרואיד 4 ומעלה\r\nמכשירי Apple עם מערכת הפעלה iOS 7 ומעלה\r\nמחשבי Mac עם מערכת הפעלה OS X® 10.6.8 ומעלה, 100MB מקום פנוי בכונן וחיבור USB פנוי\r\nמחשבי PC עם מערכת הפעלה Windows 7 ומעלה, 100MB מקום פנוי בכונן וחיבור USB פנוי', 'bluetooth-Creative-iRoar-Go-Splash-proof', '2017.02.28.11.11.01-bluetooth-Creative-iRoar-Go-Splash-proof-1 - Copy.jpg', '800.00', '2017-02-28 11:11:01', '2017-01-11 12:18:00'),
(9, 2, 'Bluetooth Wireless T15 Creative 2.0', 'מותג Creative\r\nדגם  T15\r\nערוצים  2.0\r\nממשק PL3.5mm\r\nBluetooth\r\nאחריות 3 שנים', 'Bluetooth-Wireless-T15-Creative', '2017.02.28.11.11.09-Bluetooth-Wireless-T15-Creative-2.0.jpg', '420.00', '2017-02-28 11:11:09', '2017-01-11 12:21:00'),
(10, 2, 'Z130 2.0 Logitech', 'מותג Logitech\r\nדגם  Z130\r\nערוצים  2.0\r\nהספק רמקול Speaker Power:2.5Watts Per Channel\r\nשונות  Right-to-left cable: 1.3 m (4.2 ft.)\r\nAudio-in cable: 1.5 m (4.9 ft.)\r\nPower adapter cable: 1.8 m (5.9 ft.)\r\nאחריות שנתיים', 'Z130-2.0-Logitech', '2017.02.28.11.11.19-Z130-2.0-Logitech.jpg', '149.90', '2017-02-28 11:11:19', '2017-01-11 12:22:00');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `updated_at`, `created_at`) VALUES
(1, '/', '/', '/', '2017-01-01 00:00:00', '2017-01-01 00:00:00'),
(2, '//', '//', '//', '2017-01-01 00:00:00', '2017-01-01 00:00:00'),
(3, '---', '---', '---', '2017-01-05 00:00:00', '2017-01-05 00:00:00'),
(4, '***', '***', '***', '2017-01-10 00:00:00', '2017-01-09 00:00:00'),
(5, 'Admin', 'admin@gmail.com', '$2y$10$HJrRG9mCTyGl/2ZuuZfhJ.7klQPCxzLcadtwwrC81Zx0xZ36KqgsO', '2017-01-14 10:20:00', '2017-01-14 10:20:00'),
(6, 'Moshe Malul', 'moshe@gmail.com', '$2y$10$HJrRG9mCTyGl/2ZuuZfhJ.7klQPCxzLcadtwwrC81Zx0xZ36KqgsO', '2017-01-14 10:24:00', '2017-01-14 10:24:00'),
(7, 'Dikla Vanunu', 'dikla@gmail.com', '$2y$10$HJrRG9mCTyGl/2ZuuZfhJ.7klQPCxzLcadtwwrC81Zx0xZ36KqgsO', '2017-01-14 10:31:00', '2017-01-14 10:32:00'),
(8, 'חביב ביטון', 'biton@gmail.com', '$2y$10$ynSf3fnFmXXbMzB3lbTXVuY/NjEnhknlEHPNL8AIP1CC9XpBE2Iki', '2017-01-21 09:37:26', '2017-01-21 09:37:26'),
(9, 'יעקוב ברמן', 'berman@gmail.com', '$2y$10$VTJuYZfsYidt821avV.nmOlshoSy.sZ./jIhOOIiRF22Gn2QjqCcq', '2017-01-23 17:04:19', '2017-01-23 17:04:19');

-- --------------------------------------------------------

--
-- Структура таблицы `users_rol`
--

CREATE TABLE `users_rol` (
  `user_id` int(11) NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users_rol`
--

INSERT INTO `users_rol` (`user_id`, `role`) VALUES
(5, 7),
(6, 5),
(7, 5),
(8, 5),
(9, 5);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`);

--
-- Индексы таблицы `contents`
--
ALTER TABLE `contents`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `facebook_users`
--
ALTER TABLE `facebook_users`
  ADD PRIMARY KEY (`open_id`);

--
-- Индексы таблицы `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT для таблицы `contents`
--
ALTER TABLE `contents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT для таблицы `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
