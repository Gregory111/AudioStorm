<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SignupRequest extends FormRequest {

    public function authorize() {
        return true;
    }

    public function rules() {
        return [
        'name' => 'required|min:2|max:50',
        'email' => 'required|email|unique:users,email',
        'password' => 'required|min:8|max:15|confirmed',
        ];
    }
    
    public function messages() {
        return [
            'name.required' => 'נא למלא שדה שם',
            'name.min' => 'שם חייב להיות לפחות 2 תווים',
            'name.max' => 'שם חייב להיות לא יותר מ-50 תווים',
            'email.required' => 'נא למלא שדה אימייל',
            'email.unique' => 'אימייל שהזנת כבר קיים במערכת',
            'email.email' => 'האימייל שהזנת לא תקני',
            'password.required' => 'נא למלא שדה סיסמה',
            'password.min' => 'סיסמא חייבת להיות לפחות 8 תווים',
            'password.max' => 'סיסמה חייבת להיות לא יותר מ-15 תווים',
            'password.confirmed' => 'אימות סיסמה אינו תואם לסיסמה',
        ];
    }

}
