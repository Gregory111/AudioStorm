<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SigninRequest extends FormRequest {

    // IP Blocking!!! true - it allowed for all, false - is prohibited for all
    public function authorize() {
        return true;
    }

    //List errors to show
    public function rules() {
        return [
            'email' => 'required|email',
            'password' => 'required',
            
        ];
    }
    
    //Error register in another language
    public function messages() {
        return [
            'email.required' => 'נא למלא שדה אימייל',
            'email.email' => 'האימייל שהזנת לא תקני',
            'password.required' => 'נא למלא שדה סיסמה',
        ];
    }

}
