<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Input;

class ProductRequest extends FormRequest {

    public function authorize() {
        return true;
    }

    public function rules() {
        
        $all = Input::all();
        $product_id = !empty($all['id']) ? ',' . $all['id'] : '';
        
        return [
            'category' => 'required',
            'title' => 'required',
            'url' => 'required|unique:products,url' . $product_id,
            'price' => 'required|numeric',
            'image' => 'image',
        ];
    }
    
    public function messages() {
        return [
            'category.required' => 'נא לבחור קטגוריה',
            'title.required' => 'נא למלא שדה כותרת',
            'price.required' => 'נא למלא שדה מחיר',
            'url.required' => 'נא למלא שדה Url',
            'image' => 'התמונה חייבת להיות בפורמט של תמונות',
            'url.unique' => 'URL שהזנת כבר קיים',
            'price.numeric' => 'מחיר חייב לכלול ספרות',
        ];
    }

}
