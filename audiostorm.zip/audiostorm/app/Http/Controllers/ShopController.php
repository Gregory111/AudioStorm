<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Categorie;
use App\Product;
use Cart;
use Session;

class ShopController extends MainController {

    public function categories() {
        self::$data['categories'] = Categorie::all()->toArray();
        self::$data['title'] = 'Shop categories';
        return view('content.categories', self::$data);
    }

    public function products($url_cat, Request $request) {
        self::$data['categories'] = Categorie::all()->toArray();
        Product::getProducts($url_cat, $request, self::$data);
        return view('content.products', self::$data);
    }
    
    public function item($url_cat, $url_product) {
        Product::getItem($url_product, self::$data);
        return view('content.item', self::$data);
    }

        public function addToCart(Request $request) {
        Product::addToCart($request['id']);
    }
    
    public function checkout() {
        $cartCollection = Cart::getContent();
        $cart = $cartCollection->toArray();
        sort($cart);
        self::$data['cart'] = $cart;
        self::$data['title'] = 'Checkout page';
        return view('content.checkout', self::$data);
    }
    
    public function clearCart() {
        Cart::clear();
        return redirect('shop/checkout');
    }
    
    public function updateCart(Request $request) {
        Product::updateCart($request);
    }
    
    public function order() {
        if( !Session::has('user_id') ) {
            Session::flash('sm', 'את/ה חייב/ת להתחבר כדי לבצע הזמנה');
            return redirect('user/signin?returnTo=shop/checkout');
        } else {
            Product::saveOrder();
            return redirect('shop');
        }
    }
}
