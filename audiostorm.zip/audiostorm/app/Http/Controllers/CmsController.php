<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\MenuRequest;
use App\Content;
use App\Product;
use App\Menu;
use Session;

class CmsController extends MainController {

    function __construct() {
        parent::__construct();
        $this->middleware('validAdmin');
    }

    public function dashboard() {
        return view('cms.dashboard', self::$data);
    }

    public function orders() {
        Product::getOrders(self::$data);
        return view('cms.orders', self::$data);
    }

}
