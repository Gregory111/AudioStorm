<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\SigninRequest;
use App\Http\Requests\SignupRequest;
use App\User;
use Session;
use Facebook;

class UserController extends MainController {

    function __construct() {
        parent::__construct();
        $this->middleware('validUser', ['except' => ['getLogout']]);
        session_start();
    }

    public function getSignin() {
        self::$data['title'] = 'Sign in page';
        return view('forms.signin', self::$data);
    }

    public function facebookSignin() {
        $fb = new Facebook\Facebook([
            'app_id' => '240780816384104', // Replace {app-id} with your app id
            'app_secret' => '1eb09a1cca92209226448caf72aa3c5c',
            'default_graph_version' => 'v2.8',
        ]);

        $helper = $fb->getRedirectLoginHelper();

        $permissions = ['email']; // Optional permissions
        self::$data['login_facebook'] = $loginUrl = $helper->getLoginUrl(url('user/facebook/callback'), $permissions);

        self::$data['title'] = 'Sign in Facebook';
        return view('forms.signin_facebook', self::$data);
    }

    public function facebookCallback() {

        $fb = new Facebook\Facebook([
            'app_id' => '240780816384104', // Replace {app-id} with your app id
            'app_secret' => '1eb09a1cca92209226448caf72aa3c5c',
            'default_graph_version' => 'v2.8',
        ]);

        $helper = $fb->getRedirectLoginHelper();

        try {
            $accessToken = $helper->getAccessToken();
        } catch (Facebook\Exceptions\FacebookResponseException $e) {
            // When Graph returns an error
            echo 'Graph returned an error: ' . $e->getMessage();
            exit;
        } catch (Facebook\Exceptions\FacebookSDKException $e) {
            // When validation fails or other local issues
            echo 'Facebook SDK returned an error: ' . $e->getMessage();
            exit;
        }

        if (!isset($accessToken)) {
            if ($helper->getError()) {
                header('HTTP/1.0 401 Unauthorized');
                echo "Error: " . $helper->getError() . "\n";
                echo "Error Code: " . $helper->getErrorCode() . "\n";
                echo "Error Reason: " . $helper->getErrorReason() . "\n";
                echo "Error Description: " . $helper->getErrorDescription() . "\n";
            } else {
                header('HTTP/1.0 400 Bad Request');
                echo 'Bad request';
            }
            exit;
        }
             
// Logged in
        echo '<h3>Access Token</h3>';
        var_dump($accessToken->getValue());

// The OAuth 2.0 client handler helps us manage access tokens
        $oAuth2Client = $fb->getOAuth2Client();

// Get the access token metadata from /debug_token
        $tokenMetadata = $oAuth2Client->debugToken($accessToken);
        echo '<h3>Metadata</h3>';
        var_dump($tokenMetadata);
        

// Validation (these will throw FacebookSDKException's when they fail)
        $tokenMetadata->validateAppId('240780816384104'); // Replace {app-id} with your app id
// If you know the user ID this access token belongs to, you can validate it here
//$tokenMetadata->validateUserId('123');
        $tokenMetadata->validateExpiration();

        if (!$accessToken->isLongLived()) {
            // Exchanges a short-lived access token for a long-lived one
            try {
                $accessToken = $oAuth2Client->getLongLivedAccessToken($accessToken);
            } catch (Facebook\Exceptions\FacebookSDKException $e) {
                echo "<p>Error getting long-lived access token: " . $helper->getMessage() . "</p>\n\n";
                exit;
            }

            echo '<h3>Long-lived</h3>';
            var_dump($accessToken->getValue());
            $_SESSION['fb_access_token'] = (string) $accessToken;

            /* Get user details from facebook */
            try {
                // Returns a `Facebook\FacebookResponse` object
                $response = $fb->get('/me?fields=id,name,email', $accessToken);
            } catch (Facebook\Exceptions\FacebookResponseException $e) {
                echo 'Graph returned an error: ' . $e->getMessage();
                exit;
            } catch (Facebook\Exceptions\FacebookSDKException $e) {
                echo 'Facebook SDK returned an error: ' . $e->getMessage();
                exit;
            }

            echo '<hr>';

            $user = $response->getGraphUser();
            print_r($user);

            echo '<hr>';
            echo $user['name'];
        }
    }

    public function getSignup(Request $request) {
        self::$data['title'] = 'Sign up page';
        return view('forms.signup', self::$data);
    }

    public function postSignin(SigninRequest $request) {

        $redirect = !empty($request['returnTo']) ? $request['returnTo'] : '';
        
        

        if (User::validateUser($request['email'], $request['password'])) {

            return redirect($redirect);
        } else {

            self::$data['title'] = 'Sign in page';
            return view('forms.signin', self::$data)->withErrors('דואר אלקטרוני או סיסמה שגויים');
        }
    }

    public function postSignup(SignupRequest $request) {
        User::saveUser($request);
        return redirect('user/signin');
    }

    public function getLogout() {

        Session::forget('user_id');
        Session::forget('user_name');
        Session::forget('is_admin');
        return redirect('user/signin');
    }

}

            
