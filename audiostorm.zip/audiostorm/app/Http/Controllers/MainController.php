<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Menu;
use App\Submenu;

class MainController extends Controller {
    
    static public $data = ['title' => 'AudioStorm'];
    
    function __construct() {
        self::$data['menu'] = Menu::all()->toArray();
    }
  
}
