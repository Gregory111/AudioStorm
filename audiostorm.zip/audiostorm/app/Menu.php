<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Session;
use DB;

class Menu extends Model {
    
     public function contents() {
        return $this->hasMany('App\Content');
    }
    
    static public function saveMenu($request) {
        $menu = new self();
        $menu->link = $request['link'];
        $menu->title = $request['title'];
        $menu->url = $request['url'];
        $menu->save();
        Session::flash('sm', 'תפריט חדש נוצר בהצלחה');
    }
    
    static public function updateMenu($request, $id) {
        $menu = self::find($id);
        $menu->link = $request['link'];
        $menu->title = $request['title'];
        $menu->url = $request['url'];
        $menu->save();
        Session::flash('sm', 'תפריט נערך בהצלחה');
    }
    
    static public function getMenuOrdered($menu_id) {
        $sql = "SELECT * FROM menus ORDER BY "
        . "CASE WHEN id = $menu_id THEN 0 ELSE id END";        
        return DB::select($sql);
    }
    
}
