<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use Hash;
use Session;

class User extends Model {
    
    static public function validateUser($email, $password) {
        
        $valid = false;
        $sql = "SELECT * FROM users u "
                . "JOIN users_rol r ON u.id = r.user_id "
                . "WHERE u.email = ?";
        $result = DB::select($sql, [$email]);
        
        if( $result ) {
            
            $result = $result[0];
            
            if( Hash::check($password, $result->password) ) {
                
                $valid = true;
                
                Session::set('user_id', $result->id);
                Session::set('user_name', $result->name);
                
                if( $result->role == 7 ) {
                    
                    Session::set('is_admin', true);
                    
                }
                
                Session::flash('sm', 'ברוך הבה ' . $result->name);
                
            }
            
        }
        
        return $valid;
        
    }
    
    static public function saveUser($request) {
        
        $user = new self();
        $user->name = $request['name'];
        $user->email = $request['email'];
        $user->password = bcrypt($request['password']);
        $user->save();
        $uid = $user->id;
        $sql = "INSERT INTO users_rol VALUES($uid, 5)";
        DB::insert($sql);
        Session::flash('sm', $request['name'] . ' חשבונך נוצר בהצלחה, כרגע אפשר להתחבר');
        
    }
    
}
