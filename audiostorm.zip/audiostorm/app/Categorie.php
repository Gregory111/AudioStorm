<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Intervention\Image;
use Session;
use DB;

class Categorie extends Model {

    public function products() {
        return $this->hasMany('App\Product');
    }

    static public function saveCategory($request) {

        $image_name = 'noimage.jpg';

        if ($request->hasFile('image') && $request->file('image')->isValid()) {
            $file = $request->file('image');
            $file = $request->image;
            $image_name = date('Y.m.d.H.i.s') . '-' . $file->getClientOriginalName();
            $request->file('image')->move(public_path() . '/images/categories', $image_name);
        }

        $category = new self();
        $category->title = $request['title'];
        $category->article = $request['article'];
        $category->image = $image_name;
        $category->url = $request['url'];
        $category->save();
        Session::flash('sm', 'קטגוריה חדשה נוצרה בהצלחה');
    }

    static public function updateCategory($request, $id) {

        $image_name = '';

        if ($request->hasFile('image') && $request->file('image')->isValid()) {
            $file = $request->file('image');
            $file = $request->image;
            $image_name = date('Y.m.d.H.i.s') . '-' . $file->getClientOriginalName();
            $request->file('image')->move(public_path() . '/images/categories', $image_name);
        }

        $category = self::find($id);
        $category->title = $request['title'];
        $category->article = $request['article'];

        if ($image_name) {
            $category->image = $image_name;
        }

        $category->url = $request['url'];
        $category->save();
        Session::flash('sm', 'הקטגוריה עודכנה  בהצלחה');
    }

    static public function getCategoryOrdered($category_id) {
        $sql = "SELECT * FROM categories ORDER BY "
                . "CASE WHEN id = $category_id THEN 0 ELSE id END";
        return DB::select($sql);
    }

}
