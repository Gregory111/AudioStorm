<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Session;

class Content extends Model {

    static public function getContents($url_menu, &$data) {

        $data['contents'] = [];

        if ($menu = Menu::where('url', '=', $url_menu)->first()) {

            $menu = $menu->toArray();

            if ($menu) {

                $data['title'] = $menu['title'];

                if ($contents = Menu::find($menu['id'])->contents) {

                    $contents = $contents->toArray();

                    if ($contents) {

                        $data['contents'] = $contents;
                    }
                }
            }
        }
    }
    
    static public function saveContent($request) {
        
        $content = new self();
        $content->menu_id = $request['menu'];
        $content->title = $request['title'];
        $content->article = $request['article'];
        $content->save();
        Session::flash('sm', 'תוכן נשמר בהצלחה');
        
    }
    
    static public function updateContent($request, $id) {
        
        $content = self::find($id);
        $content->menu_id = $request['menu'];
        $content->title = $request['title'];
        $content->article = $request['article'];
        $content->save();
        Session::flash('sm', 'תוכן נשמר בהצלחה');
        
    }

}
